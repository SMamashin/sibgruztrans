import './Button.scss';

// eslint-disable-next-line react/prop-types
export const Button = ({ children }) => {
    return <button className="button">{children}</button>;
};
