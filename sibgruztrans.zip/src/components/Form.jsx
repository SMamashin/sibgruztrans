import React, { useState } from "react";
import "../styles/Form.scss";

const Form = () => {
    const [serviceType, setServiceType] = useState("");
    const [formData, setFormData] = useState({
        fullName: "",
        phoneNumber: "",
        serviceType: "",
        fromAddress: "",
        toAddress: "",
        furnitureAddress: "",
        workerType: "",
        workerAddress: "",
    });

    const [errors, setErrors] = useState({});

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({ ...prevData, [name]: value }));
    };

    const validateForm = () => {
        const newErrors = {};

        if (!formData.fullName.trim()) newErrors.fullName = "Введите ФИО.";
        if (!formData.phoneNumber.trim()) {
            newErrors.phoneNumber = "Введите номер телефона.";
        } else if (!/^\+?[0-9]{10,15}$/.test(formData.phoneNumber)) {
            newErrors.phoneNumber = "Некорректный номер телефона.";
        }

        if (serviceType === "cargo") {
            if (!formData.fromAddress.trim())
                newErrors.fromAddress = "Введите адрес откуда.";
            if (!formData.toAddress.trim())
                newErrors.toAddress = "Введите адрес куда.";
        }

        if (serviceType === "furniture") {
            if (!formData.furnitureAddress.trim())
                newErrors.furnitureAddress = "Введите адрес.";
        }

        if (serviceType === "handyman") {
            if (!formData.workerType.trim())
                newErrors.workerType = "Выберите тип рабочего.";
            if (!formData.workerAddress.trim())
                newErrors.workerAddress = "Введите адрес.";
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const cleanFormData = () => {
        const cleanedData = { ...formData };

        if (serviceType !== "cargo") {
            delete cleanedData.fromAddress;
            delete cleanedData.toAddress;
        }
        if (serviceType !== "furniture") {
            delete cleanedData.furnitureAddress;
        }
        if (serviceType !== "handyman") {
            delete cleanedData.workerType;
            delete cleanedData.workerAddress;
        }

        return cleanedData;
    };

    const handleSubmit = () => {
        if (!validateForm()) return;

        const dataToSend = cleanFormData();
        console.log("Send Data:", dataToSend);

        fetch("https://api", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(dataToSend),
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("Answer server:", data);
                setFormData({
                    fullName: "",
                    phoneNumber: "",
                    serviceType: "",
                    fromAddress: "",
                    toAddress: "",
                    furnitureAddress: "",
                    workerType: "",
                    workerAddress: "",
                });
                setServiceType("");
            })
            .catch((error) => {
                console.error("Error sending:", error);
            });
    };

    return (
        <div className="page-container">
            <div className="form-container">
                <div className="form-title">оставить заявку</div>
                <div className="form-group">
                    <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        placeholder="ФИО"
                    />
                    {errors.fullName && <p className="error">{errors.fullName}</p>}
                </div>
                <div className="form-group">
                    <input
                        type="tel"
                        name="phoneNumber"
                        value={formData.phoneNumber}
                        onChange={handleInputChange}
                        placeholder="Номер телефона"
                    />
                    {errors.phoneNumber && (
                        <p className="error">{errors.phoneNumber}</p>
                    )}
                </div>
                <div className="form-group">
                    <select
                        name="serviceType"
                        value={formData.serviceType}
                        onChange={(e) => {
                            setServiceType(e.target.value);
                            handleInputChange(e);
                        }}
                    >
                        <option value="">Выберите услугу</option>
                        <option value="cargo">Грузоперевозка</option>
                        <option value="furniture">Сборка мебели</option>
                        <option value="handyman">Разнорабочий</option>
                    </select>
                    {errors.serviceType && (
                        <p className="error">{errors.serviceType}</p>
                    )}
                </div>

                {serviceType === "cargo" && (
                    <>
                        <div className="form-group">
                            <input
                                type="text"
                                name="fromAddress"
                                value={formData.fromAddress}
                                onChange={handleInputChange}
                                placeholder="Адрес откуда"
                            />
                            {errors.fromAddress && (
                                <p className="error">{errors.fromAddress}</p>
                            )}
                        </div>
                        <div className="form-group">
                            <input
                                type="text"
                                name="toAddress"
                                value={formData.toAddress}
                                onChange={handleInputChange}
                                placeholder="Адрес куда"
                            />
                            {errors.toAddress && (
                                <p className="error">{errors.toAddress}</p>
                            )}
                        </div>
                    </>
                )}

                {serviceType === "furniture" && (
                    <div className="form-group">
                        <input
                            type="text"
                            name="furnitureAddress"
                            value={formData.furnitureAddress}
                            onChange={handleInputChange}
                            placeholder="Адрес"
                        />
                        {errors.furnitureAddress && (
                            <p className="error">{errors.furnitureAddress}</p>
                        )}
                    </div>
                )}

                {serviceType === "handyman" && (
                    <>
                        <div className="form-group">
                            <select
                                name="workerType"
                                value={formData.workerType}
                                onChange={handleInputChange}
                            >
                                <option value="">Выберите рабочего</option>
                                <option value="plumber">Сантехник</option>
                                <option value="electrician">Электрик</option>
                                <option value="painter">Маляр</option>
                            </select>
                            {errors.workerType && (
                                <p className="error">{errors.workerType}</p>
                            )}
                        </div>
                        <div className="form-group">
                            <input
                                type="text"
                                name="workerAddress"
                                value={formData.workerAddress}
                                onChange={handleInputChange}
                                placeholder="Адрес"
                            />
                            {errors.workerAddress && (
                                <p className="error">{errors.workerAddress}</p>
                            )}
                        </div>
                    </>
                )}

                <button onClick={handleSubmit}>Отправить</button>
            </div>
        </div>
    );
};

export default Form;
